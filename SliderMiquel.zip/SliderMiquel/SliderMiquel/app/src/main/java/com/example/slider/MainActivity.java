package com.example.slider;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ViewFlipper;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {

    ViewFlipper v_Flipper;
    Button btnLeft, btnRight;

    String[] imageUrls = {
            "https://static.wikia.nocookie.net/ageofempires/images/1/1c/CondottieroIcon-DE.png/revision/latest/scale-to-width/360?cb=20191230141010",
            "https://static.wikia.nocookie.net/ageofempires/images/e/e1/Aoe2de_ratha_ranged.png/revision/latest/zoom-crop/width/150/height/150?cb=20220428034348",
            "https://static.wikia.nocookie.net/ageofempires/images/3/37/Aoe2de_roman_unique_centurion_icon.png/revision/latest/zoom-crop/width/150/height/150?cb=20230519231329",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuPQqjYWVO71BBmR_oZ2afU7FUNgzwtoMeKENDIwDcx0cSzq4gOH71KL7oLK3bvaidf04&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRB_ZSdiI7xFa8JW9kqT75EpZbcuGtrP681rLig6c84QKRgWYZ7H_ipv3eMLxU6pAnEYBI&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSl7smA0E4W76ZcD0_1qluBZsPoTGQpeAXo2ZNjhqjONnLs-dvXXHsLKSjEBii7mibmHH8&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrXZ93CFn88QKCqQJtvFqI8gGy3hKUlsVlmnrTsvw7Q9U4WBc2eu8EmYIBEDeHiCkmxFo&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTA3YidYAjqBligweMBFkp6UQ5ZAhqtvHG20doiWQlUiRzypWANIqCUpAWznLukPVZ11eY&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLCnlXQ7XK6yz7QaOzOsPJUUV2dQGUky_G45VRloJnniumt4kyYcIZPMshsaND-Xo8v0A&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuMWDbglgX4BAcJjfhL1pr1GHYAOQjNFL4Nyi1MQxPbAS4E-Od5Y5QHsmVxBr1nhn2lQg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYetYmS087aj_7_YHSXNhoROSTQ-bmmlgc9h8bm9Jm5JMw8cYnpDUiHAkHyPv2TPAMLC8&usqp=CAU",
            "https://static.wikia.nocookie.net/ageofempires/images/5/5e/AoE2_WarriorPriest.png/revision/latest/thumbnail/width/360/height/360?cb=20231016183620",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQc4QRFED0ihdukTKpIStJy_CNHWwFmOGxugTYw_eB1OnrrhtUm4vBq-SFmkncfnmVnKKc&usqp=CAU",
            "https://static.wikia.nocookie.net/ageofempires/images/b/b5/Konnikdismountedicon.png/revision/latest/thumbnail/width/360/height/360?cb=20191110154253",
            "https://qph.cf2.quoracdn.net/main-qimg-a931061db89d28e210ba0dc0767fa9f7-pjlq",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTO8t0LRwgXvx-RSGbA7l5JGJggWfuOFANHNY5780PnRr33Ti222CEV9rfi9C_dTGtTITU&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT14ZhYc7dP_hvsvU8q-BB1rEqs2rDSu6r--owrY8kPTRZvnf2COlOgRemS7Kv5Xpo6YyU&usqp=CAU"
    };

    int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        v_Flipper = findViewById(R.id.v_flipper);
        btnLeft = findViewById(R.id.esquerra);
        btnRight = findViewById(R.id.dreta);

        for (String imageUrl : imageUrls) {
            flipperImg(imageUrl);
        }

        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v_Flipper.setInAnimation(MainActivity.this, android.R.anim.slide_in_left);
                if (currentIndex > 0) {
                    currentIndex--;
                } else {
                    currentIndex = imageUrls.length - 1;
                }
                v_Flipper.setDisplayedChild(currentIndex);
                v_Flipper.stopFlipping(); // Stop flipping
                v_Flipper.setFlipInterval(3000); // Reset flip interval
                v_Flipper.startFlipping(); // Start flipping again
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v_Flipper.setInAnimation(MainActivity.this, android.R.anim.slide_out_right);
                if (currentIndex < imageUrls.length - 1) {
                    currentIndex++;
                } else {
                    currentIndex = 0;
                }
                v_Flipper.setDisplayedChild(currentIndex);
                v_Flipper.stopFlipping(); // Stop flipping
                v_Flipper.startFlipping(); // Start flipping again
            }
        });

    }

    public void flipperImg(String imageUrl) {
        ImageView imageView = new ImageView(this);
        Picasso.get().load(imageUrl).error(R.mipmap.ic_launcher).into(imageView);
        v_Flipper.addView(imageView);
        v_Flipper.setFlipInterval(3000);
        v_Flipper.setAutoStart(true);
    }
}
